{'name': "Tax Balance Report", 'summary': "",
       'version': "1.0",
       'depends': ['sale'],
       'author': "Sandhya Galoriya", 'contributors': "Sandhya Galoriya", 'maintainer': "Nilesh Galoriya",
       'license': '',
       'website': "http://www.ap-accounting.co.za",
       'category': 'Partner',
       'description': """
    Custoised Form View
    """,
       'data': [
                'report/tax_balance.xml',
                ],
       'qweb': [],
       'sequence': 10,
       'installable': True ,
       'auto_install':  False,
       'currency': 'ZAR'
       }

